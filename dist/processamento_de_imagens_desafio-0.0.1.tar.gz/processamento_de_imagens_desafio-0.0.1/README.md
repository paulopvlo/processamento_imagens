# processamento_de_imagens	

Description. 
The package processamento_de_imagens is used to:
    Processing:
        - Mistogram matching
        - Structural similarity
        - Resize image
    Utils:
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot mistogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name
```


## Author
paulopvlo

## License
[MIT](https://choosealicense.com/licenses/mit/)